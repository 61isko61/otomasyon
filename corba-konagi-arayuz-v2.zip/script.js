const ratings = document.querySelectorAll(".rating");
const selectedRating = document.getElementById("selected-rating");

ratings.forEach((rating) => {
  rating.addEventListener("click", () => {
    ratings.forEach((item) => {
      item.classList.remove("selected");
      item.setAttribute("aria-checked", "false");
    });

    rating.classList.add("selected");
    rating.setAttribute("aria-checked", "true");
    selectedRating.value = rating.dataset.rating;

    // Kendi backend/API kodunu burada çalıştırabilirsin.
    // Örnek:
    // fetch("/api/feedback", {
    //   method: "POST",
    //   headers: { "Content-Type": "application/json" },
    //   body: JSON.stringify({ rating: Number(selectedRating.value) })
    // });
  });
});
